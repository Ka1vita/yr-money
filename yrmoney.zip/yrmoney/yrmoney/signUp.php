<?php


$msgBox = '';


include('includes/notification.php');

include('includes/Functions.php');

include('includes/db.php');

//User Signup page
if(isset($_POST['signup'])){
	if($_POST['email'] == '' || $_POST['firstname'] == '' || $_POST['lastname'] == '' || $_POST['password'] == '' || $_POST['rpassword'] == '') {
				$msgBox = alertBox($SignUpEmpty);
			} else if($_POST['password'] != $_POST['rpassword']) {
				$msgBox = alertBox($PwdNotSame);
				
			} else {
				// Set new account
				$Email 		= $mysqli->real_escape_string($_POST['email']);
				$Password 	= encryptIt($_POST['password']);
				$FirstName	= $mysqli->real_escape_string($_POST['firstname']);
				$LastName	= $mysqli->real_escape_string($_POST['lastname']);
				$Currency	= $mysqli->real_escape_string($_POST['currency']);
				
				//Check if already register

				$sql="Select Email from user Where Email = '$Email'";

				 $c= mysqli_query($mysqli, $sql);

                    if (mysqli_num_rows($c) >= 1) {

                        $msgBox = alertBox($AlreadyRegister);
                    }
                    else{

				// add new account
				$sql="INSERT INTO user (FirstName, LastName, Email, Password, Currency) VALUES (?,?,?,?,?)";
				if($statement = $mysqli->prepare($sql)){
					//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
					$statement->bind_param('sssss', $FirstName, $LastName, $Email, $Password, $Currency);	
					$statement->execute();
				}
				$msgBox = alertBox($SuccessAccount);
				}
			}
}

if(isset($_POST['back']))
{
	header("location:login.php");
}
?>




<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> Sign Up</title>

    
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/custom.css" rel="stylesheet">


    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
   <style>
  .bg .container
   {
   	 background-image: url(css/images/m.png)  !important;
   	 background-repeat: repeat;
   	 opacity: 0.9;
   	 width:100%;
   	 height:100%
   }
   .form-control
   {
   	border-radius: 25px;
   }

   .panel-body
   {
   	margin-left: 180px;
   }
</style>
    
</head>

<body>
 <div class="bg">
    <div class="container" style=" background-image: url(css/images/m.png)  !important;
   	 background-repeat: repeat;
   	 opacity: 0.9;
   	 width:100%;
   	 height:100%">
        <div class="row" >
            <div class="col-md-6 col-md-offset-3" style="margin-top: -150px">
                <div class="login-panel panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title text-center"><span class="glyphicon glyphicon-lock"></span> <?php  echo $CreateAnAccount; ?></h3>
                    </div>
                    <div class="panel-body">
						<?php if ($msgBox) { echo $msgBox; } ?>
                        <form method="post" action="" role="form">
                            <fieldset>
                                <div class="form-group col-lg-6">
                                    <label for="email"><?php  echo $Emails; ?></label>
                                    <input class="form-control"  placeholder="<?php  echo $Emails; ?>" name="email" type="email" autofocus>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label for="email"><?php  echo $FirstNames; ?></label>
                                    <input class="form-control"  placeholder="<?php  echo $FirstNames; ?>" name="firstname" type="text" >
                                </div>
                                <div class="form-group col-lg-6">
                                    <label for="email"><?php  echo $LastNames; ?></label>
                                    <input class="form-control"  placeholder="<?php  echo $LastNames; ?>" name="lastname" type="text" >
                                </div>
                                <div class="form-group col-lg-6">
                                    <label for="email"><?php  echo $Currencys; ?></label>
                                    <select class="form-control bold"  name="currency">
										<option value="د.إ">Arab Emirates Dirham (AED)</option>
										<option value="Tk">Bangladeshi Taka (BDT)</option>
										<option value="лв">Bulgarian Lev (BGN)</option>
										<option value="R$">Brazilian Real (R$)</option>
										<option value="BSD">Bahamian Dollar (BSD)</option>
										<option value="BZD">Belize Dollar (BZD)</option>
										<option value="CA$">Canadian Dollar (CA$)</option>
										<option value="₱">Cuban Peso (CUP)</option>
										<option value="CVE">Cape Verdean Escudo (CVE)</option>
										<option value="£">Egyptian Pound (EGP)</option>
										<option value="€">Euro (€)</option>
										<option value="£">British Pound Sterling (₤)</option>
										<option value="Rp">Indonesian Rupiah (IDR)</option>
										<option value="₪">Israeli New Sheqel (₪)</option>
										<option value="₹">Indian Rupee (Rs.)</option>
										<option value="¥">Japanese Yen (¥)</option>
										<option value="KES">Kenyan Shilling (KES)</option>
										<option value="лв">Kazakhstani Tenge (KZT)</option>
										<option value="₭">Laotian Kip (LAK)</option>
										<option value="£">Lebanese Pound (LBP)</option>
										<option value="Rs">Sri Lankan Rupee (LKR)</option>
										<option value="MX$">Mexican Peso (MX$)</option>
										<option value="MYR">Malaysian Ringgit (MYR)</option>
										<option value="MT">Mozambican Metical (MZN)</option>
										<option value="$">Namibian Dollar (NAD)</option>
										<option value="₦">Nigerian Naira (NGN)</option>
										<option value="C$">Nicaraguan Córdoba (NIO)</option>
										<option value="kr">Norwegian Krone (NOK)</option>
										<option value="₨">Nepalese Rupee (NPR)</option>
										<option value="NZ$">New Zealand Dollar (NZ$)</option>
										<option value="₱">Philippine Peso (Php)</option>
										<option value="Rs">Pakistani Rupee (PKR)</option>
										<option value="zł">Polish Zloty (PLN)</option>
										<option value="Gs">Paraguayan Guarani (PYG)</option>
										<option value="S$">Singapore Dollar (SGD)</option>
										<option value="฿">Thai Baht (฿)</option>
										<option value="NT$">New Taiwan Dollar (NT$)</option>
										<option selected="" value="$">US Dollar ($)</option>
										<option value="₫">Vietnamese Dong (₫)</option>
										<option value="ZMK">Zambian Kwacha (ZMK)</option></select>
									
									</select>
                                </div>
                                <div class="form-group col-lg-6">
                                     <label for="password"><?php  echo $Passwords; ?></label>
                                    <input class="form-control"  placeholder="<?php  echo $Passwords; ?>" name="password" type="password" value="">
                               </div>
                                <div class="form-group col-lg-6">
                                     <label for="password"><?php  echo $RepeatPassword; ?></label>
                                    <input class="form-control"  placeholder="<?php  echo $RepeatPassword; ?>" name="rpassword" type="password" value="">
                               </div>
                              
                           <table border="2">
                           <div style="border-radius: 25px !important">
                            <tr >
                            	<th colspan="3"></th>
                            	<th rowpan="3"></th>
                            	<td>
                                <button type="submit" name="signup" class="btn btn-success btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php  echo $Save; ?></button>
                                </td>                                
                               <td>
                                <button type="reset"  name="reset" class="btn btn-danger btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php  echo "Reset"; ?></button>                                
                               </td>
                               <td>
                                <button type="back"  name="back" class="btn btn-primary btn-block"><span class="glyphicon glyphicon-log-in"></span>  <?php  echo "Back"; ?></button>
                            </td> </tr>
                        </div>
                                                              
                            </div>
                        </table>
                               
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php
    include('includes/footer.php');
    ?>
</div>


    <script src="js/jquery-1.11.0.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/metisMenu.min.js"></script>

    

</body>

</html>



										