<?php


include ('includes/db.php');

$UserId=$_SESSION['UserId'];
$GetUserInfo = "SELECT * FROM user WHERE UserId = $UserId";
$UserInfo = mysqli_query($mysqli, $GetUserInfo);
$ColUser = mysqli_fetch_assoc($UserInfo);
$Getincome = "SELECT CategoryId, UserId, CategoryName, Level FROM category WHERE (UserId = 0 OR UserId = $UserId) AND Level = 1";
$income = mysqli_query($mysqli,$Getincome); 
$Getexpense = "SELECT CategoryId, UserId, CategoryName, Level FROM category WHERE (UserId = 0 OR UserId = $UserId) AND Level = 2";
$expense = mysqli_query($mysqli,$Getexpense); 

// Category for account Expense
$GetAccountExpense = "SELECT AccountId, UserId, AccountName FROM account WHERE UserId = 0 OR UserId = $UserId";
$AccountExpense = mysqli_query($mysqli,$GetAccountExpense); 

// Category for account Income
$GetAccountIncome = "SELECT AccountId, UserId, AccountName FROM account WHERE UserId = 0 OR UserId = $UserId";
$AccountIncome = mysqli_query($mysqli,$GetAccountIncome); 


// income vs expense by month

$GetAccountDountdate = "SELECT AmountExpense, AmountIncome
					  FROM (  SELECT  UserId, 
                      SUM(Amount) AS AmountExpense, dates
                      FROM bills WHERE MONTH(Dates) = MONTH(current_date())
				      GROUP BY UserId) AS b
					  JOIN ( SELECT  UserId,
                      SUM(Amount) AS AmountIncome, date
				      FROM assets WHERE MONTH(Date) = MONTH(current_date())
					  GROUP BY UserId) AS a
					  ON b.UserId = a.UserId
					  WHERE b.UserId = $UserId";
$Dountvsdate 	 = mysqli_query($mysqli, $GetAccountDountdate);
$ColsDounatMonth = mysqli_fetch_assoc($Dountvsdate);

// get data based from budget
$Year 	= date("Y");
$Month  = date("m");
$Getbudget = "SELECT b.CategoryId, b.Dates, b.Amount, c.CategoryName from budget b, category c WHERE YEAR(Dates) = $Year  AND MONTH(Dates) = $Month AND b.UserId = $UserId AND c.CategoryId = b.CategoryId";
$Budget = mysqli_query($mysqli, $Getbudget);




?>
