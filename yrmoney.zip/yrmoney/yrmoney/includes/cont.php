<?php
mysql_connect("localhost" ,"root" ,"");
mysql_select_db("yrmoney");
$name=$_REQUEST['name'];
$mob=$_REQUEST['mob'];
$email=$_REQUEST['email'];
$comment=$_REQUEST['comment'];
if ($_REQUEST['go'])
 {
	$insert="insert into contact values ('$name','$mob','$email','$comment')";
	mysql_query($insert);
  }
?>
<style>
.container
{
  background-color:orange;
  border:2px solid black;
}
.col-md-06
{
  color:black;
  font-family: cursive;
  padding:20px;
  border:2px white soild;
  margin-left:10px;
  border-radius: 25px;
  border:2px solid black;
}
.form-group
{
   margin-left: 0px;
   font-family: cursive;
   
}
 .form-control
{
   margin-left: 3px;
   border-radius: 25px;
   border-bottom: :2px solid black;


}

</style>


<div class="container">
 
  <div class="col-md-06">

<form method ="post">
  
  <h1 align="center">CONTACT FORM</h1>

    <div class="form-group">
      <span class="glyphicon glyphicon-arrow-user"></span>&nbsp;
NAME:<input type="text" class="form-control" name="name"><br>

</div>

  <div class="form-group">
    <span class="glyphicon glyphicon-arrow-phone"></span>&nbsp;
MOBILE:<input type="text" class="form-control" name="mob"><br>
</div>


 <div class="form-group">
  <span class="glyphicon glyphicon-arrow-envelope"></span>&nbsp;
EMAIL:<input type="text" class="form-control" name="email"><br>
</div>


   <div class="form-group">
    <span class="glyphicon glyphicon-arrow-pencil"></span>&nbsp;
COMMENT:<input type="text"  class="form-control"name="comment"><br>
</div>



   <div class="form-group">
<button type="submit" style="border-radius: 25px"  class="btn btn-success btn-lg btn-block"  title="Click here to send"  name="go" value="Send"><span class="glyphicon glyphicon-arrow-left">Send</span>
</button>

</div>

 <button   type="Reset"  style="border-radius: 25px"   title="Click here to reset" 
 class="btn btn-danger btn-lg btn-block " ><span class="glyphicon glyphicon-arrow-left"></span>&nbsp;Reset</button>

</div>
</form>


</div>
</div>
