<html>
<head><title>slider</title>
 <link href="css/bootstrap.min.css" rel="stylesheet">
</head> 
<body>
<!-- sliding image-->
<div id="myCarousel" class="carousel slide" data-ride="carousel " >
    <!--indicators-->
    <ol class="carousel-indicators">
   <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
       <li data-target="#myCarousel" data-slide-to="1"></li>
       <li data-target="#myCarousel" data-slide-to="2"></li>
       <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>
    
    <!--wrapper for slides-->
    <div class="carousel-inner" role="listbox" >
    <!--ist image-->
        <div class="item active">
            
            <img src="css/images/a.jpg" style="height: 400px; width: 100%"alt="yrmoney analyzer">
        <div class="carousel-caption">
            <h3 style="color: black;font-size: 50px">Where to Use?</h3>
            <h4 style="color: red;font-size: 50px"> Your hard-earned money</h4>
        </div>
               
            
        </div>    
            
     <!--2nd image-->
        
            <div class="item">
                
                
            <img src="css/images/calculator.jpg" style="height: 400px; width: 100%" alt="yrmoney analyzer">
        <div class="carousel-caption">
            <h3 style="color: red;font-size: 50px">Manage</h3>
            <h4 style="color: red;font-size: 50px">Expenses?</h4>
        </div>
                   
                
        </div>
    <!--3rd image--> 
                <div class="item">
                    
                    
            <img src="css/images/1.jpeg" style="height: 400px; width: 100%"  alt="yrmoney analyzer">
        <div class="carousel-caption">
            <h3 style="color: red;font-size: 50px">Bored?</h3>
            <h4 style="color: red;font-size: 50px">Avoid  Calculations</h4>
        </div>
                       
                    
        </div>       
    <!--4th image-->    
                    <div class="item">
                        
                        
            <img src="css/images/money1.jpg" style="height: 400px; width: 100%" alt="yrmoney analyzer">
        <div class="carousel-caption">
            <h3 style="color: red ;font-size: 50px">Savings?</h3>
            <h4 style="color: red ;font-size: 50px">Money</h4>
        </div> 
                            
                        
          </div>
    <!--5TH image--> 
       
                <div class="item">
                    
           
            <img src="css/images/k.jpg"  style="height: 400px; width: 100%" alt="yrmoney analyzer">
        <div class="carousel-caption">
            <h3 style="color: black;font-size: 30px">WE can solve your budget making work?</h3>
            <h4 style="color: red;font-size: 30px">TRY our "YRMoney Analyzer"....</h4>
        </div>
                        
               
        </div> 
</div>
    
    <!--left and right controls-->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</body>
</html>

