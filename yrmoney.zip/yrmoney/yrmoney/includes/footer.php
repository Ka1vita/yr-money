


    <script src="js/jquery-1.11.0.js"></script>
	
	
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
  <link rel="stylesheet" href="css/flaticon.css"/>
  <link rel="stylesheet" href="css/slicknav.min.css"/>
  <link rel="stylesheet" href="css/jquery-ui.min.css"/>


    
<body>

<br>
        <div class="footer">  
          
         <br>
         <div class="row">
            <div style="margin-left: 420px !important; padding: 0px;margin-bottom: 0px !important">
        <ul class="pagination">
            
            
            <li><a href="index.php">«</a></li>
  <li><a class="active" href="dashboard.php">1</a</li>
  <li><a href="C:\xampp\htdocs\yrmoney\yrmoney\pages\transaction.php">2</a></li>
  <li><a href="C:\xampp\htdocs\yrmoney\yrmoney\pages\settings.php">3</a></li>
      <li><a href="index.php">»</a></li></a></li>
  
  
      </ul>

      <br>
      <p style="margin-left: 100px !important; padding: 0px;margin-bottom: 0px !important">   kavita Web Deisgn, Copyright &copy; 2019</p>
            </div>

      </div>      
    
        </div>

</div>
</body>
