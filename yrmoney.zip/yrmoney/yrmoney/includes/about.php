
<body>
<div class="about">
<div class="flip-box">
  <div class="flip-box-inner">
    <div class="flip-box-front" style="background-image: url(css/images/4.jpg);background-repeat: repeat;">
      <h2 style="font-size: 50px;font-family: cursive;color:black;font-size:100px;margin-left:35px;">ABOUT US

    </div>
    <div class="flip-box-back">
      <p>The “YRMoney Analyzer”  is to be developed to reduce the manual work carried out in home using pen,paper or copy and writting all expense with calculator and their is no track of previous expense users will be introduced with the interactive menu. This free budget calculator  will give you a clear view of your monthly finances and help you find places to  change your budget to make the most of your income.You can then create a household budget worksheet to use as a reference point for creating a budget.
<p>
This project helps the user to know  their transaction details in few seconds. Due to digitization and a step towards cashless economy, online loan and credit  system needs to be introduced.in upcoming years.  Building  a good budget is the key to managing your money. This free budget calculator  will give you a clear view of your monthly finances and help you find places to  change your budget to make the most of your income.

          
      <p>Want  help with your budget? Try  a <a href="index.php">yrmoney analyzer</a>.</p>   </p>
    </div>
  </div>
</div>

</div>
  
<br>
